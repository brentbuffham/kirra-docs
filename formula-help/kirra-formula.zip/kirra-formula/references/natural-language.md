# Natural-Language Formula Matcher ("Describe it…")

Source of truth: `src/charging/ChargeFormulaMatcher.js` (`parse` / exported as
`parseChargeFormula`, plus `buildMultiMonitorPPVFormula`) and the Interpret handler in
`src/charging/ui/DeckBuilderDialog.js`. Tests: `src/charging/__tests__/ChargeFormulaMatcher.vitest.js`.

The Deck Builder's Formula Builder has a **"Describe it…"** box: the user types a plain-English
goal, clicks **Interpret**, and Kirra fills the formula bar with an `fx:` charging formula plus a
one-line readback of what it understood. This is **only** in the charging engine (Deck Builder /
deck length, mass, and primer-depth fields). The print-template and blast-group engines have no
matcher.

## It is deterministic, not AI

The matcher is a fixed lexicon + an ordered list of template **shapes**. No model call, no
guessing. Every output is one of the documented shapes or an explicit refusal. This matters for
trust: a charge formula that silently does the wrong thing is dangerous, so the matcher would
rather refuse (the **honesty gate**) than emit a plausible-but-wrong formula. When you (the skill)
are asked "can the Describe-it box do X?", answer from the shape list below — if X isn't a shape,
it can't, and the box will say so.

## How it flows

1. `tokenize()` lowercases, applies spelling tolerance, and maps known phrases → tokens
   (e.g. "hole length"/"length"/"the length" → `holeLength`; "stem"/"stemming" → `STEM`;
   "scaled depth of burial"/"sdob"/"chiappetta" → `SDOB`).
2. `parse()` runs the **honesty gate** first (out-of-scope + needs-monitors), then walks `SHAPES`
   in order and returns the first whose `test()` passes, calling its `build()`.
3. On no match it returns `{ ok:false, reason:"no_match" }` and, if it found near-miss vocabulary,
   `suggestions` ("lenght → length") + a "Did you mean…" message — it **never auto-corrects**.
4. The Deck Builder fills the formula bar with `result.formula`, the field hint (`length` / `mass`),
   the scaling flag, and shows `result.readback`. For `needsMonitors` it resolves real monitors
   from the project (see below).

## Supported shapes (in priority order)

The `test()` order is deliberate — earlier shapes win, so more specific intents (PPV, SDoB, tiered)
resolve before the generic percent/offset shapes.

| Shape id | Plain-English trigger | Emits | Field / Flag |
|---|---|---|---|
| `min_ppv_sdob_mass` | "smaller of the PPV-allowed and SDoB-compliant mass" | `fx:Math.min(ppvKG(monitorX,monitorY,targetPPV,K,b), sdobKg(SD, "ANFO"))` | mass / `FM` |
| `max_charge_under_ppv` | "biggest charge under a PPV limit" (no monitors named) | `fx:deckBase[1] + massLength(ppvKG(monitorX,…), d)` | length / `VR` |
| `sdob_stem_clamped` | "stem to SDoB 1.5 but never under 1.6 m" | `fx:Math.max(1.6, sdobStem(1.5, "ANFO"))` (and/or `Math.min` for a max) | length / `VR` |
| `sdob_mass` | "mass of ANFO for SDoB 1.4" | `fx:sdobKg(1.4, "ANFO")` | mass / `FM` |
| `mass_as_length` | "25 kg of ANFO" | `fx:massLength(25, "ANFO")` | length / `VR` |
| `primer_above_indexed` | "primer 0.3 m above deck 4" | `fx:deckBase[4] - 0.3` | depth |
| `primer_above_deepest` | "primer 0.3 m above the deepest charge" | `fx:chargeBase - 0.3` | depth |
| `fixed_length` | "3.5 m of stemming" / "keep it 3.5 m" | `3.5` | length / `FL` |
| `proportional` | "let it absorb the rest" / no explicit target | (proportional deck, no formula) | length / `PR` |
| `tiered_percent` | "25% if hole > 5 m, 40% if 5–3 m, 75% if 3–1.5 m" | nested ternary on `holeLength` | length / `VR` |
| `explicit_conditional` | "if hole > 5 m then 25% of length else 40%"; "only if subdrill is 1 m else 35%" | single ternary | length / `VR` |
| `percent_of_var` | "stemming 25% of hole length" | `fx:holeLength * 0.25` | length / `VR` |
| `var_offset` | "hole length minus 3.5" | `fx:holeLength - 3.5` | length / `VR` |
| `bare_var` | "the hole length" | `fx:holeLength` | length / `VR` |
| `var_minus_var` | "hole length minus subdrill" | `fx:holeLength - subdrillLength` | length / `VR` |

### Conditionals — words understood

- **Branching:** `if`, `when`, `while`, `then`, `else`, `otherwise`.
- **Comparators:** "more than"/"over"/"greater than" → `>`; "less than"/"under"/"below" → `<`;
  ">=" / "<=" via "at least"/"at most"; **equality** via "is"/"equal to"/"equals" — note bare
  **"is" is the last-resort comparator**, so "is more than" still resolves to `>` (the longer
  phrase wins first). "only if … is 1 m" → `subdrillLength == 1`.
- **Tiered bands:** "25% if hole is more than 5 m and 40% if 5 to 3 m and 75% if 3 to 1.5 m"
  builds an ordered nested ternary; the final bare-var fallback is appended.
- **Distinct condition vs branch variable:** "stemming 25% of the **hole length** only if the
  **subdrill** is 1 m else 35%" → `fx:subdrillLength == 1 ? holeLength * 0.25 : holeLength * 0.35`
  (the condition tests `subdrillLength`, the branches scale `holeLength`).

### Rounding — wraps any shape

Append "round to 0.1" / "to 1 decimal" / "round up" / "round down" / "round to the nearest 0.5".

- "round to 0.1" → `Math.round((expr) * 10) / 10`
- "round up" → `Math.ceil(expr)`, "round down" → `Math.floor(expr)`
- The inner expression is **parenthesised** before the `*10` so a ternary's `else` branch can't
  bind the multiply (precedence safety): `Math.round((a ? b : c) * 10) / 10`.

### Percent-of-variable

"25% of X" → `X * 0.25`. The variable is whichever appears (`holeLength`, `benchHeight`,
`subdrillLength`). "30% stemming of the bench height" → `fx:benchHeight * 0.3`.

## Multi-monitor PPV — parser flag + project monitors

A PPV charge-limit phrase that names monitors or gives an mm/s target does **not** get refused and
does **not** invent monitor coordinates. Instead `parse()` returns a **signal**:

```js
{ ok:false, reason:"needs_monitors", needsMonitors:true,
  targetPPV: 10,          // parsed mm/s, or null
  ppvMode: "length",      // "mass" if the phrase asked for kg, else "length"
  message: "PPV charge limit — I'll use your placed PPV monitors with a target of 10 mm/s." }
```

The Deck Builder then reads `window.ppvMonitorPoints` (the monitors the user has placed on the
plan) and calls `buildMultiMonitorPPVFormula(monitors, { targetPPV, mode })`:

- one `ppvKG(x, y, target, K, b)` term per monitor, using **that monitor's own** x/y and K/b
  (fallback `K = 1140`, `b = 1.6` when a monitor has none);
- the **MIC = `Math.min(...)`** across all monitors, so PPV stays under target at *every* monitor
  (a single monitor drops the `Math.min` wrapper);
- `mode:"length"` wraps the kg in `massLength(mic, density)`; `mode:"mass"` returns the kg directly.

Example output (two monitors, 10 mm/s, length mode):

```
fx:massLength(Math.min(ppvKG(1000, 2000, 10, 1140, 1.6), ppvKG(1500, 2200, 10, 1200, 1.7)), "ANFO")
```

**If no monitors are placed,** the Deck Builder readback tells the user to add PPV monitors first —
the matcher asks for what it can't resolve from the project, rather than guessing coordinates.

## The honesty gate — what it refuses (and why)

Refusals come back as `{ ok:false, reason, message }`. They are a feature: the matcher will not
emit a charge formula for a quantity that **has no charging-engine variable** (see
`charging.md` → "What is NOT expressible"). Route these to the solver / explain they're out of
scope — do not hand-write a formula that fakes them.

| Phrase contains | `reason` | Why refused |
|---|---|---|
| "powder factor", "PF" | `out_of_scope` | No `powderFactor` variable in the charging context. |
| "burden", "spacing", "volume", "area" | `out_of_scope` | No pattern-geometry terms in the charging context. |
| "VED", "vertical energy distribution", "energy distribution" | `out_of_scope` | Not a deck variable. |
| "fragmentation", "frag size", "P80", "X50" | `out_of_scope` | Not a deck variable; needs a frag model, not a deck formula. |
| a PPV/mm-s/monitor target | `needs_monitors` | Resolvable — handed to `buildMultiMonitorPPVFormula` from project monitors (above). |
| nothing recognised | `no_match` | Returns `suggestions` + "Did you mean…" if near-miss vocab found. |

A deliberately dangerous compound such as *"4 monitors below 10 mm/s but 70% VED, or 30% of the
bench height"* is **refused** (VED is out-of-scope) rather than silently returning
`fx:benchHeight*0.7` — the gate catches the out-of-scope term before the percent shape can grab the
trailing clause.

## When documenting / explaining the matcher to a user

- It writes `fx:` only (never `=`) — consistent with the prefix policy.
- It is a **starting point**: every output carries a readback and the user can edit the formula bar
  before applying. Monitor coords / K / b in the PPV shapes are placeholders unless resolved from
  real project monitors.
- It is **English-only** today (lexicon is English phrases). Other languages are future work — do
  not claim multilingual support.
- It never reaches outside the charging engine — don't suggest it for print templates or blast
  groups.
