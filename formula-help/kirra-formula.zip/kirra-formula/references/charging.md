# Charging Engine Reference

Source of truth: `src/helpers/FormulaEvaluator.js` (`evaluateFormula`, custom functions) and
`src/charging/rules/SimpleRuleEngine.js` (`applyTemplate` — how the context is built). The
wiki pages (`Charging-System.md`, `Charge-Config-CSV-Reference.md`) are secondary and have
known gaps; where they disagree with this file, the code wins.

**Where these formulas live:** the length field of a deck, the mass field of a deck, or the
depth field of a primer — in the Deck Builder or in `chargeConfigs.csv`.

**Prefix — always emit `fx:`. `=` is legacy-accepted, never recommended.**

`isFormula`/`stripPrefix` accept **both** `fx:` and `=`, and both strip to the same expression
body and evaluate identically — the difference is purely spreadsheet-safety.

- **Always emit `fx:`** when writing a formula, *including for the in-app Deck Builder*. There is
  no context in which you should tell a user to type `=`: a user who later pastes an `=` formula
  into `chargeConfigs.csv` or any spreadsheet will have it silently parsed as a live cell formula
  and corrupted. `fx:` is safe everywhere the Deck Builder, CSV, and IndexedDB are concerned.
- **`=` is a legitimate legacy / internal prefix.** Old in-app or stored formulas may begin with
  `=`, and the evaluator honours them. When you *encounter* an `=` formula, treat it as valid and
  validate it normally; offer to convert it to `fx:` if it's headed for a spreadsheet. Do not
  silently rewrite a working `=` formula without explaining why.

Result must be a **single finite number**. NaN/Infinity → `null` → the deck/primer falls back to
its default.

**Evaluator mechanics:** the expression body (after stripping `fx:`/`=`) is run via
`new Function(names, '"use strict"; return (' + expr + ");")`. Indexed `name[N]` is rewritten
to `name_N` *before* eval — so brackets are only valid on the indexed variables listed below,
not as JS array access. Standard JS operators, ternary, and the `Math.*` listed below work.

---

## Variables

All variables are numbers. They are populated per-hole in `applyTemplate`.

### Unindexed (scalar) — refer to the hole or the *deepest* charge deck

| Variable | Meaning |
|---|---|
| `holeLength` | Total hole length, collar→toe (m). `Math.abs(holeLength)`. |
| `holeDiameter` | Hole diameter (mm). Defaults 115 if unset. |
| `benchHeight` | Bench height from hole data (m). |
| `subdrillLength` | Subdrill length from hole data (m). |
| `holeX` | Collar easting (m) — used by `ppvKG`. |
| `holeY` | Collar northing (m) — used by `ppvKG`. |
| `chargeLength` | Length of the **deepest** charge deck (m). |
| `chargeTop` | Depth collar→top of deepest charge deck (m). |
| `chargeBase` | Depth collar→base of deepest charge deck (m). |
| `firstChargeTop` | Collar→top of first charge deck — geometric uncharged zone (m). |
| `stemLength` | Total Stemming + StemGel + DrillCuttings inert deck length (m). |
| `inertLength` | Total length of all inert decks (m). |
| `airLength` | Total Air deck length (m). |
| `waterLength` | Total Water deck length (m). |

Note: scalar `chargeTop`/`chargeBase`/`chargeLength` are only meaningful for charge decks
*already laid out* when the formula runs. Decks resolve sequentially by `idx`, so a deck's
formula can reference decks above it; for decks below, use the indexed form once they exist,
or the primer context (primers are placed after all decks).

### Indexed — target a specific deck position N (1-based, matches section-view `[N]`)

`name[N]` in the formula → internally `name_N`. N is the deck array position from collar.

| Variable | Meaning |
|---|---|
| `chargeBase[N]` | Base depth of the COUPLED/DECOUPLED deck at position N. |
| `chargeTop[N]` | Top depth of charge deck at position N. |
| `chargeLength[N]` | Length of charge deck at position N. |
| `chargeDensity[N]` | Product density (g/cc) of charge deck at position N. |
| `deckBase[N]` | Base depth of the deck at position N (ANY deck type). |
| `deckTop[N]` | Top depth of deck at position N. |
| `deckLength[N]` | Length of deck at position N. |
| `deckDensity[N]` | Product density (g/cc) of deck at position N. |

`deckDensity[N]` / `chargeDensity[N]` are **pre-populated for all decks before layout**, so
any deck's formula can reference any deck's density regardless of resolution order. This lets a
formula adapt to product swaps without naming a product literally, e.g.
`fx:massLength(ppvKG(...), deckDensity[2])`. *(These three — `deckDensity[N]`,
`chargeDensity[N]`, `sdobKg` — are in the code but not in the wiki as of transcription.)*

---

## Custom Functions

Exactly four. Each is bound to the current hole's geometry. Density arguments accept a numeric
g/cc value **or** a product-name string (looked up in `window.loadedProducts`); an unknown name
returns 0.

### `massLength(massKg, densityOrProductName)` → length (m)

Length of explosive column holding `massKg` at the hole diameter.
`length = massKg / (density × 1000 × π × (holeDiameter/2000)²)`.
Returns 0 for non-positive mass or unresolved density.

```
fx:chargeTop[4] - massLength(50, 0.85)      # 50 kg ANFO column above deck 4
fx:chargeTop[4] - massLength(50, "ANFO")    # same, density looked up by name
```

### `sdobStem(targetSDoB, densityOrProductName)` → stemming length (m)

Stemming required to hit a target Scaled Depth of Burial (Chiappetta `SDoB = D / Wt^(1/3)`,
`D = stem + 0.5·contributingLen`, `contributingLen = min(chargeLen, m·diam)`, `m=10` for
≥100 mm else 8). Closed-form for long holes, iterates (<10 iters, 1 mm tol) for short holes.
Clamped to `[0, holeLength·0.9]`. Returns **unrounded** — round in the formula if needed.

```
fx:sdobStem(1.5, 1.2)                    # stem for SDoB 1.5, emulsion 1.2 g/cc
fx:Math.max(sdobStem(1.5, 1.2), 2.5)     # SDoB stem, minimum 2.5 m
```

### `sdobKg(targetSDoB, densityOrProductName)` → mass (kg)

Inverse of `sdobStem`: the deck mass that achieves the target SDoB at current hole length and
diameter. Solves stem via `sdobStem`, then `kg = (holeLength − stem) × massPerMetre`. Returns
3-dp rounded. Intended for the **mass field** of a coupled deck.

```
fx:Math.min(ppvKG(x,y,4,1140,1.6), sdobKg(1.4,"ANFO"))   # smaller of PPV-allowed and SDoB-compliant mass
```

### `ppvKG(monitorX, monitorY, targetPPV, K, b)` → MIC (kg)

Max Instantaneous Charge satisfying a PPV target at a monitor, via scaled-distance law
`PPV = K·(D/Q^0.5)^(−b)` → `Q = D²·(targetPPV/K)^(2/b)`, where `D` is collar→monitor horizontal
distance from `holeX`/`holeY`. Returns 0 if D≤0 or any of `targetPPV`/`K`/`b` ≤ 0. Each hole
gets a different result (different distance).

```
fx:ppvKG(500000, 6000000, 5, 1140, 1.6)
fx:deckBase[1] + massLength(ppvKG(500000, 6000000, 5, 1140, 1.6), 1.2)
```

---

## Operators & Math

- Arithmetic `+ - * /`, parentheses.
- Ternary `cond ? a : b`; comparison `< > <= >= == !=`; logical `&& || !`.
- `Math.min`, `Math.max`, `Math.abs`, `Math.sqrt`, `Math.PI`, `Math.round`. *(Bare `Math.*`
  works here because charging uses `new Function`, unlike the print engine.)*

---

## A Formula Is Closed-Form — One Expression, Evaluated Once Per Deck

This is the single biggest authoring trap. A charging formula is **one declarative expression
evaluated a single time per deck per hole.** It has **no loops, no state, no convergence, no
goal-seek.** You cannot write "reduce stemming by 100 mm until SDoB is met", "keep lowering the
charge while PPV is above target", or "iterate toward powder factor 0.65". The formula author
never gets a loop. (The internal iteration inside `sdobStem` for short holes is hidden inside the
bound function — it is not something the author writes or controls.)

### Translate goal-seek language into (scaling flag + clamp/conditional + bound function)

When the user describes an *iterative* or *target-seeking* intent, do not refuse outright and do
not fake a loop. Re-express it as a per-hole **scaling mode** carried by an explicit flag, with the
target met by a clamp/conditional and/or a bound function:

- **"vary X per hole" / "recompute for each hole"** → a **`VR`** (Variable) deck. The formula
  re-evaluates against each hole's geometry; per-hole variation comes from the flag + the formula,
  never from author-written iteration.
- **"hit a target SDoB, but never below 1.6 m stemming"** → clamp around a bound function:
  `fx:Math.max(1.6, Math.min(2.0, sdobStem(1.5, "ANFO")))` on a `VR` deck.
- **"largest charge that keeps PPV under target"** → `ppvKG(...)` (the closed-form inverse of the
  site law) feeding `massLength(...)`, optionally `Math.min` with another cap.
- **"smaller of PPV-allowed and SDoB-compliant mass"** → `fx:Math.min(ppvKG(...), sdobKg(...))` in
  the **mass** field.
- **"let this deck soak up whatever length is left"** → a **`PR`** (Proportional) deck — no formula
  target; it absorbs remaining space.
- **"keep this exact length / mass regardless of hole"** → **`FL`** / **`FM`**.

The rule: **map the goal to (flag + clamp/conditional + bound function). If no variable or bound
function can carry the goal, it is out of scope — say so and point to the solver.**

### What is NOT expressible in a charging formula (do not fake it)

The `FormulaEvaluator` context exposes **only hole geometry and deck depths**. It does **not**
expose any of the following, and there is **no** custom function for them, so a formula that
targets them is impossible today:

| Not available | Consequence |
|---|---|
| `powderFactor` | **No PF-driven charge in a deck formula.** There is no variable to multiply a target PF against. PF needs the solver, or it's out of scope. |
| `burden`, `spacing` | No pattern-geometry term to compute volume/PF from. |
| `area`, `cellVolume` | No per-hole influence volume. |
| live `PPV` reading | Only the *inverse site law* (`ppvKG`) is available — you target a PPV, you cannot read one back and react. |

(`benchHeight` and `subdrillLength` **are** in the context — those are fine to use. It's the
PF/pattern/volume terms specifically that are absent.) If the user asks for any of the above in a
deck formula, state plainly that it isn't a charging-formula variable, and route them to the
solver workflow rather than emitting a plausible-looking formula that silently does the wrong
thing.

---

## `m:` Mass Mode (length field, not a formula)

In a deck **length** field, `m:50` means "50 kg of this product" — length computed per-hole
from density and diameter (same formula as `massLength`). Not an `fx:` expression; it's a
length-mode prefix in the CSV/Deck Builder.

## Scaling Flags (CSV deck entries `{idx,length,product,FLAG}`)

`FL` fixed length · `FM` fixed mass · `VR` variable (re-evaluate formula per hole; auto-set for
`fx:` length decks) · `PR` proportional (default). Pass 1 lays out FL/FM/VR, pass 2 distributes
remaining space to PR decks.

**Choose the flag from the user's intent — this is where goal-seek language gets resolved:**

| User intent | Flag | Why |
|---|---|---|
| "recompute / vary this per hole", any `fx:` that references hole geometry | `VR` | Formula re-evaluates against each hole. Auto-set for formula length decks. |
| "keep this deck the same metres on every hole" | `FL` | Length frozen regardless of hole length. |
| "keep this deck the same kilograms" | `FM` | Length recomputed to hold constant mass at the new diameter. |
| "let this absorb the leftover length" / no explicit target | `PR` | Soaks up remaining space in pass 2. |

> **Proposed prefixes `VFX:`/`PFX:`/`MFX:` are NOT real** — the evaluator does not parse them
> today. Always emit the actual `VR`/`FL`/`FM`/`PR` flags above. If the user references those
> prefixes, treat them as the corresponding flag and note they're proposed, not live.

## Primer Depth Formulas

Primer `depth` field accepts a number or `fx:`. The primer context includes all scalar vars
plus the indexed `chargeBase[N]`/`chargeTop[N]`/`chargeLength[N]` and `deckBase[N]` etc.
(primers are placed after every deck, so all indices exist). Out-of-range/null → falls back to
`holeLength·0.9`; final depth clamped to `[0.1, holeLength−0.1]`.

```
fx:chargeBase - 0.3        # 0.3 m above deepest charge base
fx:chargeBase[8] - 0.6     # 0.3/0.6 m above a specific deck in a multi-deck design
```

---

## Failure Table

| Symptom | Likely cause | Fix |
|---|---|---|
| Deck reverts to default length | Formula returned `null` (unknown var, or NaN/Infinity) | Check every identifier is in the variable list; check division by zero |
| `massLength`/`sdob*` returns 0 unexpectedly | Product name not in `loadedProducts`, or density 0/missing | Use numeric density, or verify the product name exactly |
| `ppvKG` returns 0 | Monitor == collar (D=0), or K/b/target ≤ 0 | Check monitor coords and site constants |
| `chargeBase[N]` is 0 / wrong | Referencing a deck position that isn't a charge deck, or below current deck before it's laid out | Use the correct 1-based position; for downstream decks use indexed form only after they exist (or use primer context) |
| Brackets treated literally | `name[N]` only works on the *indexed* variables; `[ ]` is not generic array access | Use a listed indexed variable name |
