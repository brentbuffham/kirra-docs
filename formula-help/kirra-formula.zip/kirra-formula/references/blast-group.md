# Blast Group Predicate Engine Reference

Source of truth: `src/helpers/FormulaEvaluator.js` (`evaluateFormulaBoolean`) and the wiki
`Blast-Groups.md`. Used by the **Formula field of the Assign Group dialog** to select holes.

**Where these formulas live:** the multiline Formula field when creating/refreshing a blast
group. Evaluated against every hole in the target entity; matching holes become members.

**Prefix — always emit `fx:`; `=` is legacy-accepted.** Like the charging engine, the blast-group
evaluator (`evaluateFormulaBoolean`) uses the same `isFormula`/`stripPrefix`, so it **accepts both
`fx:` and `=`**. Always *write* `fx:` to users — never recommend `=`, because a predicate copied
toward a spreadsheet would be cooked by the leading `=`. If you *encounter* an existing `=`
predicate, it's valid; validate it normally and offer to convert to `fx:` if needed. The result
**must be a boolean** — truthy → hole is included.

**Evaluator mechanics:** body run via `new Function(names, '"use strict"; return (' + expr +
");")` with `!!result`. Unlike the charging evaluator, **string variable values are kept as
strings** (not coerced to Number) — so string equality like `holeType=="Production"` works.
Indexed `name[N]` → `name_N` rewrite happens (same as charging), but blast-group formulas
operate on a single hole's properties, so indexed forms are rarely used here.

**Error behaviour:** a parse error or unknown-variable reference throws; the dialog shows a
**modal error** with the message and the formula text, and the group is **not** created or
modified. Fix and retry. (In strict mode the error propagates; otherwise evaluation returns
`false`.)

---

## Variables

Per the wiki `Blast-Groups.md`, available against each hole:

### Formal names
`holeLength` / `holeLengthCalculated`, `holeDiameter`, `holeType`, `holeAngle`, `holeBearing`,
`benchHeight`, `subdrillAmount`, `subdrillLength`, `burden`, `spacing`,
`startX`, `startY`, `startZ`, `endX`, `endY`, `endZ`, `gradeZ`,
`timingDelayMilliseconds`, `measuredLength`, `measuredMass`.

### Short aliases (convenience)
`length`, `depth`, `diameter`, `type`, `angle`, `bearing`, `bench`, `subdrill`, `delay`,
`rowID`, `posID`.

> Note: these names are documented in the wiki. The actual variable map is assembled by the
> caller (the Assign Group dialog) and passed into `evaluateFormulaBoolean`. If a name doesn't
> resolve, the formula errors — so verify against the dialog's variable set if a name is
> rejected, and treat the alias list as the documented contract.

---

## Operators

- Comparison: `< > <= >= == !=`
- Logical: `&&` (AND), `||` (OR), `!` (NOT)
- Parentheses: `( )`
- String equality: `holeType == "Production"` (string values preserved, so this works)

`&&`/`||` are JS logical operators here (NOT rewritten to `+` — that rewrite is a
*print-template* behaviour only). Do not use the print-template aggregation functions or the
charging custom functions here; this engine exposes **no functions**, only operators on the
hole's variables.

---

## Examples (from `Blast-Groups.md`)

```
fx:holeLength > 2
fx:subdrill <= 0
fx:holeType == "Production"
fx:holeType != "Batter"
fx:diameter == 115 && length > 8
fx:burden >= 4 && (spacing >= 5 || spacing < 10)
fx:(type == "Production" || type == "Presplit") && depth < 3
fx:!(holeLength > 5) && bearing > 90
```

Use-case predicates:
```
fx:measuredLength < plannedLength * 0.9     # short-drilled (note: plannedLength must be a provided var)
fx:holeType == "Production" && burden >= 4.5
fx:depth < 3                                # shallow holes needing reduced charge
```

---

## Failure Table

| Symptom | Likely cause | Fix |
|---|---|---|
| Modal error, group not created | Parse/syntax error, or unknown variable name | Check operators/parentheses; use a documented variable or alias |
| Predicate matches nothing | String compared as number, or wrong field name | Quote string literals; verify alias resolves in the dialog |
| Used a function and it failed | This engine has **no functions** | Express the condition with operators only |
| `&&`/`||` behaved oddly | Confusing with print-template `&` concat rewrite | Here `&&`/`||` are plain logical operators; single `&` is not concat |
