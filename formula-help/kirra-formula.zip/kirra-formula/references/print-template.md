# Print Template Engine Reference

Source of truth: `src/print/template/TemplateFormulaEvaluator.js` (functions, render tokens,
iteration, `filter()`) and `src/print/template/TemplateVariables.js` (scalar vars, the
`getAvailableVariables()` catalogue). Engine entry point: `src/print/template/TemplateEngine.js`.

**Where these formulas live:** a **cell in an XLSX print template** (rendered to populated XLSX
or PDF). Each sheet ≈ one print page.

**Prefix:** `fx:` (leading whitespace before `fx:` is allowed). Output is text or a render
token. A non-formula cell value is passed through unchanged.

**Evaluator mechanics (important — differs from charging):** the body is compiled then run via
`Function("$$ctx", "with($$ctx){return(" + compiled + ")}")`. Compilation steps:
1. `field[i]` → `__field_field` (array for aggregation).
2. `&` (not `&&`) → `+` (string concatenation).
3. `if(` → `$$if(` (JS reserved word).
4. `field[N]` (literal index, 1-based) and `[++]`/`[--]`/`[+>]` are resolved to values/indices
   *before* eval.

**Bare `Math.*` is NOT available.** Use the library functions (`min`, `max`, `abs`, `sqrt`,
`pow`, `pi`, `floor`, `ceil`, `round`, …) below.

---

## Scalar Variables (from `buildTemplateContext`)

User input: `blastName`, `designer`, `paperSize`, `orientation`, `printScale`.
Aggregates: `holeCount`, `drillMetres`, `totalMass`, `totalVolume`, `totalSurfaceArea`,
`powderFactor`, `entityCount`, `entityNames` (comma-joined), `entityName` (first).
Surfaces: `surfaceCount`, `kadCount`.
Date/time: `date`, `time`, `datetime`.
Per-entity (name sanitised to `[A-Za-z0-9_]`): `<entity>_holeCount`, `_drillMetres`, `_expMass`,
`_volume`, `_surfaceArea`, `_burden`, `_spacing`, `_minFiringTime`, `_maxFiringTime`.

---

## Iterated Fields — `field[i]`

`field[i]` inside an aggregation expands to the array of that field over visible holes. Used
*only* inside aggregation functions, e.g. `sum(holeLength[i])`.

**Hole-property fields** (alias → actual property; both short and full names work):
`holeLength`(→holeLengthCalculated), `holeDiameter`/`diameter`, `holeAngle`/`angle`,
`holeBearing`/`bearing`, `holeType`, `holeID`/`holeId`, `entityName`,
`startX/Y/Z`, `endX/Y/Z`, `gradeX/Y/Z`, `benchHeight`, `subdrillAmount`, `subdrillLength`,
`burden`, `spacing`, `measuredMass`, `measuredLength`, `measuredComment`,
`timingDelay`/`holeTime`(→timingDelayMilliseconds), `rowID`, `posID`, `color`(→colorHexDecimal),
`fromHoleID`, `connectorCurve`, `visible`.

**Charging-derived fields** (resolved from `window.loadedCharging`, not hole properties):
`totalMass`, `deckCount`, `explosiveDeckCount`, `firstChargeTop`, `stemLength`, `chargeLength`,
`primerCount`, `powderFactor`, `productName`, `airLength`/`air`, `inertLength`,
`waterLength`/`waterDeckLength`, `spacerCount`/`spacers`.

---

## Indexed & Auto-Increment Row Syntax

- `field[N]` — Nth visible hole, **1-based**. Out-of-range → cell blanks (unless `ignore()`
  used). Works with Excel refs, e.g. `="fx:holeID["&$A1&"]"`.
- `field[++]` — auto-increment one hole per row (1,2,3…). Rows beyond hole count are hidden.
- `field[--]` — auto-decrement (last hole first).
- `field[+>]` — grid-increment, one hole per **cell**, left→right then top→bottom. Auto-paginates
  by bands.
- `fx:filter(condition)` — pre-filters visible holes for the page before `[++]`/`[+>]` indexing.
  Supports `> < >= <= == !=` joined by `&&`/`||` (e.g. `fx:filter(holeAngle > 0 && holeDiameter >= 200)`).

---

## Function Library (from `buildFunctionLibrary`)

### Aggregation (take a `field[i]` array)
`sum`, `count`, `avg`, `median`, `stdev`, `unique` (count of distinct),
`countif(field[i], val)`, `sumif(sumF[i], condF[i], val)`,
`join(field[i], sep=", ")`, `uniqueList(field[i], sep=", ")`.

### Grouping (return formatted multi-line strings)
- `sortCount(field[i], sep=", ", limit=0)` — "Production: 85, Buffer: 15" by count desc.
- `groupCount(field[i], sep="\n", order=desc|asc|alpha)`.
- `groupSum(sumF[i], grpF[i], sep="\n", order)`; `groupAvg`, `groupMin`, `groupMax` (Min/Max
  default order `alpha`).
- `groupTable(grpF[i], fmt, sep="\n", order=desc)` — tokens `{key} {count} {sum:field}
  {avg:field} {min:field} {max:field} {median:field}`. e.g.
  `groupTable(holeType[i], "{key}: {count} holes, dia={avg:holeDiameter}mm", "\n")`.

### Connector / product (read holes + `loadedCharging`)
`connectorList(sep)`, `connectorCount(delay?)`, `productList(sep)`, `productMass(name)`,
`productCount(name?)`.

### Two-level blast summaries (entity → holeType)
- `blastSummary(sep="\n", indent="  ")` — geometry: holes, pattern B×S×AvBH, diameter, angle
  min/max, subdrill min/max, total metres.
- `chargeSummary(sep="\n", indent="  ")` — charging: charged count, depth-to-first-charge,
  charge length, total/avg mass, powder factor, products, primers. Returns "No charging data"
  if empty.

### Math / rounding (use these, NOT bare `Math.*`)
`round(v, n)` (negative n → tens/hundreds), `roundup(v,n)`, `rounddown(v,n)`, `ceil`, `floor`,
`abs`, `sqrt`, `pow(base,exp)`, `pi()`, `log`, `log10`, `min(...)`, `max(...)`,
`isnumber(v)`, `ignore(v)` (blank-on-empty, also suppresses out-of-range blanking).

### Date
`today(offset?)`, `now()`, `dateformat(fmt)` (tokens `YYYY MM DD hh mm ss`). en-AU locale.

### String
`upper`, `lower`, `trim`, `len`, `left(t,n)`, `right(t,n)`, `mid(t,start,len)`,
`text(v, fmt)` ("0.00" → 2 dp), `fixed(v, n)`.

### Conditional
`if(cond, trueVal, falseVal)` (compiled to `$$if`). `isblank(v)`.

### String concatenation
Use `&` (rewritten to `+`). e.g. `="Total: " & round(sum(holeLength[i]),1) & " m"`.

---

## Render Tokens (produce graphics, matched at start of expression)

`legend(code, orient=h|v)`, `northArrow`, `scale`, `scaleBar`, `scaleText`, `logo`, `qrcode`,
`mapView` / `mapView(r[,dpi])` (raster) / `mapView(v[,pt])` (vector), `connectorCount`,
`holeSection(entity, holeID)`, `sectionView(entity, holeID1, holeID2)`.
Args may be scalar var names or indexed fields (e.g. `holeID[3]`), which are resolved to values.
A merged cell region defines the render bounding box.

---

## Worked Examples

```
fx:"Total drill: " & round(sum(holeLength[i]),1) & " m"
fx:countif(holeType[i], "Production")
fx:avg(holeDiameter[i])
fx:groupCount(holeType[i], "\n", "desc")
fx:groupTable(holeType[i], "{key}: {count} holes, avg {avg:holeLength}m", "\n")
fx:holeID[++]                       # one hole per row
fx:filter(holeAngle > 0)           # restrict page to angled holes, then [++]/[+>]
fx:if(holeCount > 100, "Large blast", "Small blast")
fx:mapView(v, 8pt)
```

---

## Failure Table

| Symptom | Likely cause | Fix |
|---|---|---|
| Cell shows `#ERR: …` | JS exception — often bare `Math.x`, or a function not in the library | Use the library function (`min`/`round`/…); check spelling |
| Cell shows `ERR` | Result was a non-finite number | Guard division; check inputs |
| Cell is blank | `field[N]` index > hole count (out-of-range blanks) | Wrap in `ignore(...)` if intended, or check the index |
| `&&`/`||` broke | `&` is rewritten to `+`; only `&&`/`||` are logical — single `&` is concat | Use `&&`/`||` for logic, single `&` only for string join |
| Aggregation returns 0/empty | `field[i]` name not in the field list, or charging not loaded | Verify the field alias; charging fields need `loadedCharging` |
| Charging field empty | Hole not in `loadedCharging`, or no explosive decks | Confirm the hole is charged |
