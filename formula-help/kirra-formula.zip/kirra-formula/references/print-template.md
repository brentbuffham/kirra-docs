# Print Template Engine Reference

Source of truth: `src/print/template/TemplateFormulaEvaluator.js` (functions, render tokens,
iteration, `filter()`) and `src/print/template/TemplateVariables.js` (scalar vars, the
`getAvailableVariables()` catalogue). Engine entry point: `src/print/template/TemplateEngine.js`.

**Where these formulas live:** a **cell in an XLSX print template** (rendered to populated XLSX
or PDF). Each sheet ≈ one print page.

**Prefix:** `fx:` (leading whitespace before `fx:` is allowed). Output is text or a render
token. A non-formula cell value is passed through unchanged.

**Evaluator mechanics (important — differs from charging):** the body is compiled then run via
`Function("$$ctx", "with($$ctx){return(" + compiled + ")}")`. Compilation steps:
1. `field[i]` → `__field_field` (array for aggregation).
2. `&` (not `&&`) → `+` (string concatenation).
3. `if(` → `$$if(` (JS reserved word).
4. **`=` (single) → `==`** — Excel-style comparison (see below).
5. `field[N]` (literal index, 1-based) and `[++]`/`[--]`/`[+>]` are resolved to values/indices
   *before* eval.

**Steps 2–4 run in ONE quote-aware pass and skip string literals** (1.1.20.245). Before that
they were applied to the whole expression, so `fx:"Drill & Blast"` compiled to `"Drill + Blast"`.
Non-formula cells (no `fx:`) are passed through untouched and were never affected.

**`=` behaves as comparison, like Excel.** In JavaScript `=` is assignment, which evaluates to
the assigned value — so `fx:if(blastName = "", entityNames, blastName)` assigned `""`, took the
false branch, and returned blank. Reported by a user 2026-08-01 and fixed by rewriting a lone
`=` to `==`. `==`, `!=`, `<=`, `>=` are untouched.

**Bare `Math.*` is NOT available.** Use the library functions (`min`, `max`, `abs`, `sqrt`,
`pow`, `pi`, `floor`, `ceil`, `round`, …) below.

---

## Scalar Variables (from `buildTemplateContext`)

User input: `blastName`, `designer`, `paperSize`, `orientation`, `printScale`.
Aggregates: `holeCount`, `drillMetres`, `totalMass`, `totalVolume`, `totalSurfaceArea`,
`powderFactor`, `entityCount`, `entityNames` (comma-joined), `entityName` (first).
Surfaces: `surfaceCount`, `kadCount`.
Date/time: `date`, `time`, `datetime`.
Per-entity (name sanitised to `[A-Za-z0-9_]`): `<entity>_holeCount`, `_drillMetres`, `_expMass`,
`_volume`, `_surfaceArea`, `_burden`, `_spacing`, `_minFiringTime`, `_maxFiringTime`.

---

## Iterated Fields — `field[i]`

`field[i]` inside an aggregation expands to the array of that field over visible holes. Used
*only* inside aggregation functions, e.g. `sum(holeLength[i])`.

**Hole-property fields** (alias → actual property; both short and full names work):
`holeLength`(→holeLengthCalculated), `holeDiameter`/`diameter`, `holeAngle`/`angle`,
`holeBearing`/`bearing`, `holeType`, `holeID`/`holeId`, `entityName`,
`startX/Y/Z`, `endX/Y/Z`, `gradeX/Y/Z`, `benchHeight`, `subdrillAmount`, `subdrillLength`,
`burden`, `spacing`, `measuredMass`, `measuredLength`, `measuredComment`,
`timingDelay`/`holeTime`(→timingDelayMilliseconds), `rowID`, `posID`, `color`(→colorHexDecimal),
`fromHoleID`, `connectorCurve`, `visible`.

**⚠️ TIMING — `holeTime` is NOT the firing time.** `holeTime` and `timingDelay` both alias
`timingDelayMilliseconds`, the **surface tie delay** (the connector between holes). Use
**`fireTime[i]`** for when a hole actually fires. It is resolved through `resolveHoleFireMs()`,
the canonical resolver: electronic `delayMs` is ABSOLUTE, nonel is
`holeTime + downhole delay + VOD travel`, and the earliest primer wins on a multi-primed hole.

On an **electronic** blast the difference is enormous — the tie is harness wire at 0 ms, so a
report using `holeTime[i]` showed a firing window of 0–9 ms for a blast firing over 975–2077 ms
(real user report, 2026-08-01). Kirra now warns before printing if a template reads the tie
delay on an electronic blast.

A hole with no resolvable fire time (NaN connector, downstream of one, or untied) yields nothing
rather than falling back to its tie delay.

**Charging-derived fields** (resolved from `window.loadedCharging`, not hole properties):
`totalMass`, `deckCount`, `explosiveDeckCount`, `firstChargeTop`, `stemLength`, `chargeLength`,
`primerCount`, `powderFactor`, `productName`, `airLength`/`air`, `inertLength`,
`waterLength`/`waterDeckLength`, `spacerCount`/`spacers`.

---

## Indexed & Auto-Increment Row Syntax

- `field[N]` — Nth visible hole, **1-based**. Out-of-range → cell blanks (unless `ignore()`
  used). Works with Excel refs, e.g. `="fx:holeID["&$A1&"]"`.
- `field[++]` — auto-increment one hole per row (1,2,3…). Rows beyond hole count are hidden.
- `field[--]` — auto-decrement (last hole first).
- `field[+>]` — grid-increment, one hole per **cell**, left→right then top→bottom. Auto-paginates
  by bands.
- `fx:filter(condition)` — pre-filters visible holes for the page before `[++]`/`[+>]` indexing.
  Supports `> < >= <= == !=` joined by `&&`/`||` (e.g. `fx:filter(holeAngle > 0 && holeDiameter >= 200)`).

---

## Function Library (from `buildFunctionLibrary`)

### Aggregation (take a `field[i]` array)
`sum`, `count`, `avg`, `median`, `stdev`, `unique` (count of distinct),
`countif(field[i], val)`, `sumif(sumF[i], condF[i], val)`,
`join(field[i], sep=", ")`, `uniqueList(field[i], sep=", ")`.

### Grouping (return formatted multi-line strings)
- `sortCount(field[i], sep=", ", limit=0)` — "Production: 85, Buffer: 15" by count desc.
- `groupCount(field[i], sep="\n", order=desc|asc|alpha)`.
- `groupSum(sumF[i], grpF[i], sep="\n", order)`; `groupAvg`, `groupMin`, `groupMax` (Min/Max
  default order `alpha`).
- `groupTable(grpF[i], fmt, sep="\n", order=desc)` — tokens `{key} {count} {sum:field}
  {avg:field} {min:field} {max:field} {median:field}`. e.g.
  `groupTable(holeType[i], "{key}: {count} holes, dia={avg:holeDiameter}mm", "\n")`.

### Connector / product (read holes + `loadedCharging`)
`connectorList(sep)`, `connectorCount(delay?)`, `productCount(name?)`.

`productList(sep, category?, filter?)` — both extra arguments optional and composable:
- **category**: `Explosive` (bulk + packaged), `Bulk`, `Packaged`, `Inert`, `Spacer`,
  `Initiator`, `All`. Plurals and any capitalisation work. Buckets on the product's own
  `productCategory`, so it cannot disagree with the charging model.
  **An unrecognised category matches NOTHING** — a typo blanks the cell rather than silently
  printing the full list.
- **filter**: same syntax as `fx:filter(...)`, e.g. `'holeType == "Production"'`.

```
fx:productList(", ", "Explosive")                              GENERIC7030G: 64308.3kg
fx:productList(", ", "Inert")                                  Stemming: 0.0kg
fx:productList(", ", "Explosive", "holeType == \"Production\"")
```

`productMass(name, filter?)` takes the same hole filter.

`cordLength(allowance?)` — total detonating-cord metres incl. trunk runs and closing legs.
`harnessLength(allowance?)` — total harness / surface-wire metres incl. trunk runs. Both take
an optional waste allowance string: `"+10%"` adds ten percent, `"+10d"` adds ten metres.

```
fx:harnessLength("+10%")
```

### Harness path (electronic tie-in sheets)
`harnessPathCount()`, `harnessLabel(path)`, `harnessCount(path)`, `harnessHoleCount(path)`,
`harnessSequence(path, pos)`. All 1-based; out-of-range returns blank, not an error.

`harnessLabel` uses the same scheme as the 3D harness labels (1=A, 26=Z, 27=AA).
**`harnessCount` counts DETONATORS, not holes** — two primers per hole across ten connections
is twenty. Grouping matches what BPDWriter emits, so a printed tie-in agrees with the export.

```
fx:"Path " & harnessLabel(1) & ": " & harnessCount(1) & " dets"
fx:harnessSequence(1, 1)      first hole on path A, in run order
```

### Two-level blast summaries (entity → holeType)
- `blastSummary(sep="\n", indent="  ")` — geometry: holes, pattern B×S×AvBH, diameter, angle
  min/max, subdrill min/max, total metres.
- `chargeSummary(sep="\n", indent="  ")` — charging: charged count, depth-to-first-charge,
  charge length, total/avg mass, powder factor, products, primers. Returns "No charging data"
  if empty.

### Math / rounding (use these, NOT bare `Math.*`)
`round(v, n)` (negative n → tens/hundreds), `roundup(v,n)`, `rounddown(v,n)`, `ceil`, `floor`,
`abs`, `sqrt`, `pow(base,exp)`, `pi()`, `log`, `log10`, `min(...)`, `max(...)`,
`isnumber(v)`, `ignore(v)` (blank-on-empty, also suppresses out-of-range blanking).

### Date
`today(offset?)`, `now()`, `dateformat(fmt)` (tokens `YYYY MM DD hh mm ss`). en-AU locale.

### String
`upper`, `lower`, `trim`, `len`, `left(t,n)`, `right(t,n)`, `mid(t,start,len)`,
`text(v, fmt)` ("0.00" → 2 dp), `fixed(v, n)`.

### Conditional
`if(cond, trueVal, falseVal)` (compiled to `$$if`). `isblank(v)`.

### String concatenation
Use `&` (rewritten to `+`). e.g. `="Total: " & round(sum(holeLength[i]),1) & " m"`.

---

## Render Tokens (produce graphics, matched at start of expression)

`legend(code, orient=h|v)`, `northArrow`, `scale`, `scaleBar`, `scaleText`, `logo`, `qrcode`,
`mapView` / `mapView(r[,dpi])` (raster) / `mapView(v[,pt])` (vector), `connectorCount`,
`holeSection(entity, holeID)`, `sectionView(entity, holeID1, holeID2)`.
Args may be scalar var names or indexed fields (e.g. `holeID[3]`), which are resolved to values.
A merged cell region defines the render bounding box.

---

## Worked Examples

```
fx:"Total drill: " & round(sum(holeLength[i]),1) & " m"
fx:countif(holeType[i], "Production")
fx:avg(holeDiameter[i])
fx:groupCount(holeType[i], "\n", "desc")
fx:groupTable(holeType[i], "{key}: {count} holes, avg {avg:holeLength}m", "\n")
fx:holeID[++]                       # one hole per row
fx:filter(holeAngle > 0)           # restrict page to angled holes, then [++]/[+>]
fx:if(holeCount > 100, "Large blast", "Small blast")
fx:mapView(v, 8pt)
```

---

## Failure Table

| Symptom | Likely cause | Fix |
|---|---|---|
| Cell shows `#ERR: …` | JS exception — often bare `Math.x`, or a function not in the library | Use the library function (`min`/`round`/…); check spelling |
| Cell shows `ERR` | Result was a non-finite number | Guard division; check inputs |
| Cell is blank | `field[N]` index > hole count (out-of-range blanks) | Wrap in `ignore(...)` if intended, or check the index |
| `&&`/`||` broke | `&` is rewritten to `+`; only `&&`/`||` are logical — single `&` is concat | Use `&&`/`||` for logic, single `&` only for string join |
| Aggregation returns 0/empty | `field[i]` name not in the field list, or charging not loaded | Verify the field alias; charging fields need `loadedCharging` |
| Charging field empty | Hole not in `loadedCharging`, or no explosive decks | Confirm the hole is charged |
| `if(x = "", a, b)` returns blank | Was JS assignment, not comparison | Fixed 1.1.20.245 — `=` now compiles to `==` |
| `&` inside a label became `+` | Rewrites hit string literals | Fixed 1.1.20.245 — rewrites skip strings |
| Firing window is a few ms on an electronic blast | Reading `holeTime`/`timingDelay` (the surface tie) | Use `fireTime[i]` |
| `productList` category prints nothing | Category word not recognised | Use Explosive/Bulk/Packaged/Inert/Spacer/Initiator/All |
| Every hole-derived value is 0 or blank | The print sees no visible holes | Check Entity Filter and visibility; Kirra warns first |
