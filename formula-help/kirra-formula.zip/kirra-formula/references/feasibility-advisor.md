# Feasibility & Advisory Layer (Charging)

**Status: advisory guidance only. This is reasoning the skill applies when helping author or
apply a charge config — it is NOT enforced by code today.** A per-hole validation pass does not
yet exist in `SimpleRuleEngine`; charging is currently *set-and-apply*, not *evaluate-and-verify*.
So the skill can **recommend** the right flag and **warn** about likely failures, but must not
claim Kirra will catch them automatically. (Writing the validation pass is future work, out of
scope for the formula skill.)

Use this layer whenever a config built off one reference hole will be applied across a selection
of holes with varying lengths.

---

## Why this matters

The Deck Builder previews/scales off a **reference hole**. When the same config is applied to a
selection, the rule engine *can* evaluate per hole (formulas reference `holeLength` etc.), but
**nothing verifies the per-hole outcome is valid.** A config designed on an 8 m hole can run on a
4 m hole and silently produce a bad layout: decks overflowing the collar, negative deck lengths,
stemming under minimum, or charge ≤ 0. Proportional (`PR`) scaling in particular just scales
blindly off the reference proportions.

The formula author's defence is to **anticipate this and pick the right flag + clamps**, and to
**advise the user** when the selection looks risky.

---

## 1. Length-distribution advisor (recommend before applying)

When a config is about to be applied to a selection, reason about the hole-length spread. If you
have the numbers (or can ask for them), compute min / max / range% / stdev over the selection:

- **Wide spread** (large range%, high stdev) → recommend **`VR`** formula decks so each hole
  re-evaluates, with clamps to protect short holes. Fixed/proportional will overflow or starve the
  short holes.
- **Uniform** (tight spread) → `FL`/`PR` are fine.

Phrase it as a recommendation, e.g.:

> "These holes span 4.2–9.8 m (≈130% range). A proportional or fixed config tuned on the long
> holes will overflow the short ones — I'd use a Variable (`VR`) charge deck with a stemming clamp
> like `fx:Math.max(1.6, holeLength*0.25)`. Want that?"

This is the "lengths are changing, so use a variable formula" reasoning made explicit.

---

## 2. Per-hole feasibility checks (warn / flag — cannot enforce yet)

For each hole the config would build, the *intended* invariants are:

- total deck length ≤ hole length (no overflow past the collar, no overlap)
- stemming ≥ minimum (e.g. 1.6 m — confirm the site minimum with the user; not a code constant)
- every charge deck length ≥ 0 (no negative decks)
- charge column > 0 where a charge is intended

Since nothing enforces these today, the skill's job is to **build the formula so the invariants
hold by construction** — i.e. use clamps:

- stemming floor: `fx:Math.max(1.6, …)`
- length cap so a deck can't exceed available space: `fx:Math.min(holeLength - stemFloor - toeGap, …)`
- guard against negatives: `fx:Math.max(0, …)`

and to **call out** holes/configs that can't satisfy them (e.g. "on a 3 m hole, a 2 m stemming
floor plus a 1.5 m fixed toe charge can't fit — that hole needs a different config").

---

## 3. Apply summary (guard — describe, don't fabricate)

The ideal apply UX surfaces a results summary before commit, in the same idiom as a bulk-edit
progress dialog, e.g.:

> "14 holes OK · 3 holes: stemming < 1.6 m · 1 hole: charge overflows collar."

**This summary does not exist in the code yet.** Do not tell the user Kirra shows it. You may
*recommend building it* (it's the natural guard), and you can produce the equivalent reasoning
manually: walk the selection, apply the formula logic per hole, and report which holes would
violate the invariants. Present that as your own analysis, not as a Kirra feature.

---

## Connection to the formula skill

- The scaling flags (`VR`/`FL`/`FM`/`PR`) make per-deck intent explicit; the (future) validation
  pass is what would verify the intent held per hole. Intent + enforcement = robust. Today we have
  intent (flags + clamps) and **advisory** enforcement (this layer), not automatic enforcement.
- The same hole-length statistics that drive the advisor here would also feed any future
  PF-volume / bench-height calculation — but remember those terms are **not** in the charging
  formula context (see `charging.md` → "What is NOT expressible"), so PF stays in the solver, not
  the deck formula.
