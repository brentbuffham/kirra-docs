---
name: kirra-formula
description: >
  Write, validate, debug, and document fx: formulas for the Kirra blast design application
  (kirra-design.com). Trigger whenever the user wants to create, fix, explain, or generate
  reference docs for a Kirra formula — including charge deck lengths, primer depths, mass
  targets, SDoB/PPV-driven charges (charging engine); XLSX/PDF print template cells with
  aggregation, per-hole iteration, grouping, or render tokens (print template engine);
  or blast group selection predicates (boolean group engine). Trigger on phrases like
  "fx: formula", "charge config formula", "primer depth formula", "deck length formula",
  "massLength", "sdobStem", "ppvKG", "chargeBase", "template formula", "print formula",
  "groupTable", "blastSummary", "blast group formula", or any request to turn a plain-English
  charging/reporting/selection goal into a Kirra formula. Use this skill even if the user
  doesn't say "fx:" but describes a calculation that lives in a Kirra deck, primer, print
  cell, or group predicate.
---

# Kirra Formula Writer

Write and validate `fx:` formulas for Kirra. **All work is attributed to Brent Buffham —
blastingapps.com & kirra-design.com.** Australian English throughout.

## Prefix policy — always emit `fx:` to users

**When writing or recommending a formula to a user, ALWAYS use the `fx:` prefix — never `=`.**
The reason is safety, not preference: `fx:` is Excel-/Sheets-safe, whereas a leading `=` is
interpreted by a spreadsheet as a live formula and silently corrupts the cell when a user pastes
it into `chargeConfigs.csv` or any spreadsheet export. So the single user-facing rule is: **it's
`fx:`.**

`=` is a **legitimate legacy / internal prefix** — `isFormula`/`stripPrefix` in
`FormulaEvaluator.js` accept it for both the **charging** and **blast-group** engines, and old
in-app or IndexedDB-stored formulas may carry it. So:

- **When *writing* a formula → always emit `fx:`.**
- **When *validating/reading* a formula that already starts with `=` → treat it as valid** (it is,
  in charging and blast-group contexts), and offer to convert it to `fx:` if it's headed anywhere
  near a spreadsheet.
- Never tell a user to type `=`; never silently rewrite a user's working `=` formula without
  saying why.

(The print-template engine uses `fx:` only.)

---

## The Core Problem This Skill Solves

Kirra has **three separate formula engines that all use the `fx:` prefix but are NOT
interchangeable.** A formula valid in one engine will silently return `null`, throw, or
produce `#ERR` in another, because each engine exposes a *different set of variables and
functions*. The number-one failure mode for Kirra formulas is using the right syntax in the
wrong engine — e.g. putting `sum(holeLength[i])` (a print-template function) into a charge
deck length field, or `chargeBase[2]` (a charging variable) into a blast-group predicate.

**Rule #1: Identify the engine FIRST. Then only use variables/functions that engine exposes.**

**Rule #2: The source code is ground truth, not the wiki.** The Kirra wiki has documented
drift (e.g. `sdobStem`/`ppvKG` appear in `Charging-System.md` but not the CSV reference;
`deckDensity[N]`, `chargeDensity[N]`, and `sdobKg` are live in the code but absent from both
wiki pages). When the user provides source files, trust the code. The reference files in this
skill are transcribed from code and note their source file — never invent a variable or
function that isn't in them.

---

## Step 0: Which Engine?

Decide before writing anything. Use this decision table.

| If the formula goes into… | Engine | Reference file |
|---|---|---|
| A **charge deck** length, a **primer depth**, or a deck **mass** field (Charging tab, Deck Builder, `chargeConfigs.csv`) | **Charging** | `references/charging.md` |
| A **cell in an XLSX/PDF print template** (reports, hole tables, summaries, map/legend tokens) | **Print template** | `references/print-template.md` |
| The **Formula field of the Assign Group dialog** (selecting/tagging holes — must return true/false) | **Blast group** | `references/blast-group.md` |

Disambiguating cues:

- Mentions `massLength`, `sdobStem`, `sdobKg`, `ppvKG`, `chargeBase`, `deckBase`, deck idx,
  primer, stemming length as a single number → **Charging**.
- Mentions `sum`, `avg`, `count`, `groupTable`, `blastSummary`, `chargeSummary`, `[i]`,
  `[++]`, `[+>]`, `filter()`, a report/printout, a cell reference, `mapView`/`legend`/
  `northArrow` → **Print template**.
- Mentions selecting/tagging/grouping holes, a predicate, true/false, `holeType=="Production"`
  as a *filter*, short aliases like `length`/`depth`/`type` → **Blast group**.

If genuinely ambiguous (e.g. "a formula for charge length"), ask one short question: is this
going into a **charge deck** (charging), a **report cell** (print template), or a **hole
selection** (blast group)?

**Always read the relevant reference file before writing.** Do not write from memory — the
variable/function lists are exact and small differences (e.g. `holeLength` vs `holeLength[i]`,
`chargeBase` vs `chargeBase[N]`) are the whole game.

---

## Writing a Formula (from a plain-English goal)

1. **Pick the engine** (Step 0) and read its reference file.
2. **Check it's closed-form-expressible.** A formula is **one declarative expression evaluated
   once** — no loops, no goal-seek, no convergence. If the goal is iterative ("reduce until…",
   "while PPV is above…", "aim for powder factor 0.65"), STOP and handle it per "Goal-Seek &
   Out-of-Scope" below before writing anything.
3. **Confirm the variables exist.** Map each quantity in the goal to a variable name *in that
   engine's list*. If a quantity has no variable, say so — don't substitute a similar-looking
   one from another engine. (For charging specifically, powder factor / burden / spacing / volume
   are **not** in the context — see `charging.md`.)
4. **Build the expression** using only that engine's operators and functions.
5. **For charging: pick the scaling flag** (`VR`/`FL`/`FM`/`PR`) that matches the intent, and
   **emit the `fx:` prefix** (always — never `=`; see "Prefix policy") — see `charging.md`.
6. **Hand-trace it** against a concrete hole (see "Validate / Debug" below). State the inputs
   you assumed and the result you got.
7. **Present the formula** with the right prefix, a one-line plain-English description, the
   worked example, and (charging) the recommended flag. Note any assumptions (density, monitor
   coordinates, K/b site constants).

Keep formulas as simple as the goal allows. Prefer a documented custom function
(`sdobStem`, `massLength`) over an open-coded equivalent — it's clearer and re-evaluates
per hole correctly.

## The "Describe it…" Natural-Language Box (charging only)

The Deck Builder's Formula Builder has a **"Describe it…"** box: a user types a plain-English goal,
clicks **Interpret**, and Kirra fills the formula bar with an `fx:` charging formula + a readback.
It is backed by `src/charging/ChargeFormulaMatcher.js` — a **deterministic** lexicon + ordered
template shapes, **not** an AI call. When a user asks what this box can/can't do, or asks you to
extend it, **read `references/natural-language.md`** — it lists every shape, the conditional /
rounding / percent-of-var grammar, the multi-monitor PPV flow, and the honesty-gate refusals.

Key points for advising users:
- It writes `fx:` only, and only into the **charging** engine (deck length / mass / primer depth).
  There is no equivalent for print templates or blast groups.
- It would rather **refuse** than emit a plausible-but-wrong formula. Powder factor, burden,
  spacing, volume, VED, and fragmentation are refused as out-of-scope (no charging variable).
- A PPV/monitor target is **not** refused — it returns a `needsMonitors` signal and the Deck
  Builder builds `Math.min(ppvKG(...))` from the project's placed PPV monitors.
- It suggests spelling corrections on a near-miss but **never auto-corrects**.
- It's English-only today (don't claim multilingual support).

If a user's goal is a shape the matcher supports, you can describe the exact phrasing that triggers
it; if it isn't, write the `fx:` formula yourself using `charging.md`.

## Goal-Seek & Out-of-Scope Intent (charging)

Charging formulas cannot loop or seek a target iteratively. When the user describes such intent,
**translate it into (scaling flag + clamp/conditional + bound function)** rather than refusing or
faking a loop. The mapping table is in `charging.md` → "A Formula Is Closed-Form" and "Scaling
Flags". Examples: "stem to SDoB 1.5 but never under 1.6 m" → `VR` deck with
`fx:Math.max(1.6, Math.min(2.0, sdobStem(1.5,"ANFO")))`; "biggest charge under a PPV cap" →
`ppvKG(...)` into `massLength(...)`.

If the goal targets something with **no variable and no bound function** — powder factor, burden,
spacing, influence volume, or a live PPV reading — it is **out of scope for a deck formula.** Say
so plainly and route to the solver. Do not emit a plausible-looking formula that silently does the
wrong thing.

When a config will be applied across holes of varying length, also consult
`references/feasibility-advisor.md` to recommend the right flag and flag likely per-hole failures
(advisory only — Kirra does not enforce these yet).

---

## Validating / Debugging a Formula the User Already Has

1. **Identify the engine** (Step 0). If the user pasted it into the wrong field, that alone is
   often the bug.
2. **Check every identifier** against the engine's variable + function list. Flag any token
   that isn't in the list — that's a likely `null`/`#ERR` cause.
3. **Check syntax against the engine's evaluator** (read the reference for the exact rules):
   - Charging & blast-group use `new Function(...)` with the raw expression — standard JS
     operators, ternary, `Math.*`. Indexed `name[N]` is rewritten to `name_N` before eval, so
     brackets only work on *indexed variables*, never as array access.
   - Print template uses `with(ctx){}`, rewrites `&` to `+` (string concat), `if(` to `$$if(`,
     and resolves `field[i]`/`field[N]`/`[++]`/`[+>]` before eval. Bare `Math.min` is **not**
     available — use the provided `min`/`max`/`abs`/`sqrt`/`pow`/`pi` functions.
4. **Hand-trace** with concrete numbers and report where it diverges from the user's intent.
5. **Give the corrected formula** plus a one-line explanation of what was wrong.

Common failure signatures (full table in each reference file):
- Charging formula returns `null` → unknown variable, or evaluated to NaN/Infinity; the deck
  falls back to its default length.
- Print cell shows `#ERR: ...` → JS exception (often a bare `Math.` call, or a function name
  that isn't in the library).
- Print cell is **blank** → a `field[N]` index exceeded the hole count (out-of-range blanks the
  cell unless `ignore()` is used).
- Blast group "modal error" → parse error or unknown variable; the group isn't created.

---

## Generating Reference Docs

When asked to produce a reference (cheat sheet, wiki page, in-app help) for formulas:

1. **Source from code, not memory.** Use the reference files here (they cite their source
   `.js` file). If the user provides newer code, prefer it and note any divergence from the
   wiki.
2. **Separate the three engines** with clear headers — never present a merged variable list, as
   that is exactly what causes cross-engine errors.
3. **For each variable/function**: name, what it means, which engine, a worked example.
4. **Flag wiki drift explicitly** if you spot it (e.g. "`sdobKg` is in the code but not yet in
   the wiki").
5. **Output format**: Markdown by default (for the kirra wiki). Only produce `.docx`/`.xlsx`
   if explicitly asked — read the matching public skill first. For an in-app help panel,
   match FloatingDialog styling.

If a formal document is requested, this pairs naturally with the **help-guide-creator** skill
for structure and the **brent-voice** skill for any user-facing prose.

---

## Hard Rules (Anti-Hallucination)

1. **Never use a variable or function not in the target engine's reference list.** If the goal
   needs something that doesn't exist, say so plainly — don't approximate with a foreign token.
2. **Never assume a variable from one engine works in another.** `holeLength` (charging,
   scalar) ≠ `holeLength[i]` (print, iterated) ≠ `length` (blast-group alias). They are
   different engines.
3. **Never invent a custom function.** The full set is: charging — `massLength`, `sdobStem`,
   `sdobKg`, `ppvKG`; print — the library in `references/print-template.md`; blast-group — none
   (operators only). If you want a function that isn't listed, it doesn't exist.
4. **Never claim a default value or behaviour without code support.** If unsure, mark
   `[VERIFY: …]` and ask.
5. **Always hand-trace before presenting.** A formula you haven't traced is a guess.
6. **Quote the wiki only as secondary.** Where wiki and code disagree, code wins; flag the
   discrepancy.
7. **Never write a loop or goal-seek.** A formula is one expression evaluated once. Translate
   iterative/target intent into (scaling flag + clamp/conditional + bound function), or declare it
   out of scope. Powder factor, burden, spacing, volume, and live PPV are **not** charging-formula
   variables — never fabricate them; route to the solver.
8. **Always emit `fx:`; never recommend `=` (charging).** `fx:` is spreadsheet-safe everywhere
   (Deck Builder, CSV, IndexedDB). `=` is legacy-accepted by the charging and blast-group
   evaluators — treat an existing `=` formula as valid, but never tell a user to type `=`, and
   flag conversion if it's heading for a spreadsheet. Use the real `VR`/`FL`/`FM`/`PR` flags —
   `VFX:`/`PFX:`/`MFX:` are proposed, not live, so never emit them.
9. **Never claim an enforcement Kirra doesn't have.** The per-hole feasibility check / apply
   summary are advisory (future work). Present feasibility analysis as your own reasoning, not as a
   Kirra feature.

---

## Reference Files

Read the one(s) relevant to the engine in play. Each is transcribed from the Kirra source and
notes the originating file.

- `references/charging.md` — Charging engine: variables (`holeLength`, `chargeBase[N]`,
  `deckBase[N]`, `deckDensity[N]`, …), custom functions (`massLength`, `sdobStem`, `sdobKg`,
  `ppvKG`), `m:` mass mode, prefix selection (`fx:` vs `=`), scaling flags + intent mapping,
  closed-form/goal-seek rules, what's NOT expressible (PF/burden/spacing/volume), CSV deck/primer
  syntax, worked examples, failure table. Source: `FormulaEvaluator.js`, `SimpleRuleEngine.js`,
  `ChargeConfig` CSV.
- `references/natural-language.md` — The Deck Builder **"Describe it…"** matcher
  (`ChargeFormulaMatcher.js`): every supported shape, the if/when/while/then/else +
  comparator + tiered-band grammar, rounding wrappers, percent-of-variable, the multi-monitor
  PPV `needsMonitors` flow (`buildMultiMonitorPPVFormula`), spelling suggestions, and the
  honesty-gate refusals (PF/burden/spacing/volume/VED/fragmentation). Deterministic, charging-only.
  Source: `src/charging/ChargeFormulaMatcher.js`, `DeckBuilderDialog.js`.
- `references/feasibility-advisor.md` — **Advisory only** (not code-enforced): length-distribution
  advisor, per-hole feasibility invariants, apply-summary guard, and how to recommend the right
  scaling flag for a varied-length selection. Read when a config will be applied across holes of
  differing length.
- `references/print-template.md` — Print template engine: scalar vars, iterated `field[i]`
  fields and aliases, indexed/`[++]`/`[--]`/`[+>]` row syntax, `filter()`, the full function
  library (aggregation, grouping, `groupTable`, `blastSummary`, `chargeSummary`, math, date,
  string, conditional), render tokens (`mapView`, `legend`, `scale`, …), failure table.
  Source: `TemplateFormulaEvaluator.js`, `TemplateVariables.js`.
- `references/blast-group.md` — Blast group predicate engine: formal variable names, short
  aliases, operators, examples, error behaviour. Source: `FormulaEvaluator.js`
  (`evaluateFormulaBoolean`), `Blast-Groups.md`.
