﻿Kirra Design - portable (no install)

1. Unzip this folder anywhere you can write to, such as Documents.
2. Run Kirra-Design.exe.

Needs Microsoft Edge WebView2 Runtime, already part of Windows 11 and
up-to-date Windows 10. If Kirra does not open, get it free from Microsoft:
https://developer.microsoft.com/microsoft-edge/webview2/

The app is not code-signed, so Windows SmartScreen may warn the first time:
click More info, then Run anyway. Tip: right-click the .zip, Properties,
tick Unblock, then unzip - Windows then does not flag the extracted files.

Settings and saved work live in your Windows user profile (the same place
an installed Kirra uses), not in this folder.

No download at all: https://kirra-design.com
