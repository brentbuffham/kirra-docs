---
name: KirraDesign-USER-Print-Skill
description: Author XLSX print templates for Kirra (kirra-design.com) — blast reports, hole tables, load sheets, tie-in sheets and plan drawings. Trigger whenever the user wants to build, fix or explain a Kirra print template: fx: formulas in spreadsheet cells, a table repeating one hole per row, per-hole-type summary blocks, harness/tie-in sheets, map views, legends, north arrows, scale bars, page setup, or a printed report whose numbers come out 0, blank or #ERR. Also trigger on "print template", "blast report", "load sheet", "Kirra-DesignPRINTReferenceTemplate", "mapView", "groupTable", or "fx:" in a spreadsheet context.
---

# Kirra Print Templates

Kirra prints from an ordinary **Excel workbook**. You design the page in Excel — borders,
fills, fonts, merged cells, column widths, page setup — and put `fx:` formulas in the cells
that should be filled with blast data. Kirra evaluates those cells against the loaded blast
and renders the sheet to PDF, or writes a populated XLSX.

**Kirra is by Brent Buffham — blastingapps.com | kirra-design.com.**

Australian English. This is mining work — use the correct blasting terms (burden = the
perpendicular distance between rows, collar/toe = the ends of a hole, subdrill, stemming,
deck, bench). Never translate them into everyday meanings.

---

## 1. The rules that matter most

1. **Every formula cell starts with `fx:`.** Not `=`. A leading `=` makes Excel try to
   evaluate it and corrupts the cell. Anything without `fx:` prints exactly as typed —
   that is how you write labels.
2. **One sheet = one printed page.** A ten-sheet workbook is a ten-page report; the user
   ticks which sheets to print.
3. **The sheet NAME sets the paper.** `A4-Summary`, `A3-Landscape-R`, `A3-Portrait-V` —
   Kirra reads size and orientation from the name, falling back to the sheet's own Excel
   page setup.
4. **Merged cells are the bounding box for graphics.** A `mapView` or `legend` fills the
   region you merged. Un-merged, it gets one small cell.
5. **Cell text is clipped to its row.** Content that does not fit is cut off — it never
   pushes the row taller. Size the row for what you expect (see §5).
6. **Join text with `&`**: `fx:"Holes: " & count(holeID[i])`. A single `&` concatenates;
   `&&` and `||` are logic.
7. **Bare `Math.` is not available.** Use `round`, `min`, `max`, `abs`, `sqrt`, `pow`, `pi()`.
8. **`=` compares, as it does in Excel.** `fx:if(blastName = "", entityNames, blastName)`
   works. `==` works too, and `!=`, `<=`, `>=` are unaffected. An `&` or `=` **inside quotes**
   is left alone, so `fx:"Drill & Blast"` prints as written.

---

## 2. One value vs many

**A single number for the whole blast** — a scalar, or an aggregation:

```
fx:holeCount                                  142
fx:round(sum(holeLength[i]),1) & " m"         1927.3 m
fx:countif(holeType[i], "Production")         118
```

`field[i]` means "this field across every visible hole" and only works **inside** an
aggregation — `sum`, `avg`, `count`, `min`, `max`, `median`, `stdev`.

**One hole per row** (hole table / load sheet) — `[++]`:

```
A5: fx:holeID[++]     B5: fx:round(holeLength[++],1)     C5: fx:holeDiameter[++]
A6: fx:holeID[++]     B6: fx:round(holeLength[++],1)     C6: fx:holeDiameter[++]
```

Every `[++]` on the **same row** is the **same hole**. Row 5 is hole 1, row 6 is hole 2.
Rows past the last hole are hidden automatically — copy the row down as far as you will
ever need.

**One hole per cell, left to right** — `[+>]`, for a grid of hole IDs. Paginates itself.

**A specific hole** — `fx:holeID[3]` is the 3rd visible hole (1-based).

---

## 3. Only some of the holes

`fx:filter(...)` in a cell restricts that whole sheet before any indexing:

```
fx:filter(holeAngle > 0)
fx:filter(holeType == "Production" && holeDiameter >= 200)
```

Supports `> < >= <= == !=` joined with `&&` / `||`.

**Printing uses VISIBILITY, not selection** — the report sees the holes visible on screen.
To report one blast out of several, hide the others.

---

## 4. Per-hole-type blocks

`groupTable` builds one formatted block per hole type **in a single cell**:

```
fx:groupTable(holeType[i], "{key}\nHoles: {count}\nTotal Drill: {sum:holeLength}m", "\n\n", "desc")
```

Tokens: `{key} {count} {sum:field} {avg:field} {min:field} {max:field} {median:field}`.

**⚠️ It returns EVERY group in ONE cell.** If your layout has a separate cell per hole type
side by side, `groupTable` fills only the first and overflows it. For that layout write one
cell per type with `countif` / `sumif`:

```
fx:if(countif(holeType[i],"Production")>0,"Production\nHoles: "&countif(holeType[i],"Production")&"\nTotal Drill: "&fixed(sumif(holeLength[i],holeType[i],"Production"),1)&"m","")
```

The `if(countif(...)>0, …, "")` guard matters: without it a hole type absent from this blast
divides by zero and shows `ERR`. With it the cell is simply blank.

Use `fixed(v,1)` rather than `round(v,1)` when you want a trailing zero — `round(229,1)`
prints `229`, `fixed(229,1)` prints `229.0`.

### Product lists

`productList` on its own returns everything loaded in the blast:

```
fx:productList(", ")        GENERIC7030G: 64308.3kg, Stemming: 0.0kg
```

Add a **category** to get one kind of product, and a **filter** to restrict which holes count.
The filter uses the same syntax as `fx:filter(...)`:

```
fx:productList(", ", "Explosive")                              GENERIC7030G: 64308.3kg
fx:productList(", ", "Inert")                                  Stemming: 0.0kg
fx:productList(", ", "Explosive", "holeType == \"Production\"")  explosives in production holes only
```

Categories: `Explosive` (bulk + packaged), `Bulk`, `Packaged`, `Inert`, `Spacer`,
`Initiator`, `All`. Plurals and any capitalisation work.

**A category Kirra does not recognise returns an empty cell, not everything.** So a typo like
`"Explosve"` shows blank rather than quietly printing the full list and looking right.

`productMass` takes the same filter:

```
fx:productMass("GENERIC7030G", "holeType == \"Production\"")
```

---

## 5. Making a block fit

Multi-line content — anything with `\n`, and `groupTable` especially — is drawn as a block,
centred in its cell, and **clipped** to the row. If lines go missing:

- Make the row taller in Excel (row height in points).
- **Merge the cell across the columns it should span.** An un-merged cell is only as wide as
  its own column, so text clips early and column dividers show through the block.
- Tick **Wrap Text** if long lines should wrap rather than run on.
- Or split the content across several cells (§4).

---

## 6. Timing — read before reporting firing times

| Field | What it is |
|---|---|
| `fireTime[i]` | **When the hole fires.** Use this for firing windows. |
| `holeTime[i]` / `timingDelay[i]` | The **surface tie delay** — the connector between holes. |

```
fx:"Window: " & min(fireTime[i]) & " – " & max(fireTime[i]) & " ms"
```

**On an electronic blast these differ enormously.** The tie is harness wire at 0 ms, so
`holeTime[i]` reports a window of a few milliseconds while the blast actually fires over
seconds. A report showing `0 – 9 ms` on an electronic shot is reading the wrong field.

Likewise `connectorList()` / `connectorCount()` group holes by **surface tie delay** — on an
electronic blast they describe the harness, not a timed connector product. Kirra warns about
both of these before it prints.

### Use `surfaceProductList()` for a bill of materials

`connectorList()` answers *"what delays are on this shot"*. It cannot answer *"what do I
take to the bench"*, for three reasons:

- it groups by **delay value**, so 5 g and 10 g detonating cord — both 0 ms — are one line;
- it walks each hole's single `fromHoleID`, so the **extra cord feeds** on a cord row are
  invisible, and a cord row is fed from more than one direction by design;
- it has **no unit**, and cord is bought by the metre.

`surfaceProductList()` answers the BOM question. It groups by **product**, counts the extra
feeds and every trunk run, and carries a unit:

```
fx:surfaceProductList(", ")     5g Detcord: 1240.5m, DRC: 18ea, MSC 25ms: 42ea
fx:cordLength()                 1240.5
fx:cordLength("+10%")           1364.6      metres plus ten percent
fx:cordLength("+10d")           1250.5      metres plus ten metres
fx:harnessLength()              860.0
fx:harnessLength("+10%")        946.0       same allowance forms as cordLength
fx:harnessLength("+10d")        870.0
fx:surfaceProductQty("DRC")     18
fx:surfaceProductQty("5g Detcord", "+10%")  1364.6
fx:surfaceProductUnit("DRC")    ea
```

**The waste allowance works on every length.** `cordLength`, `harnessLength` and
`surfaceProductQty` all take the same two forms — `"+10%"` for a percentage, `"+10d"` for a
flat number of metres. It is ignored for anything counted `ea`, because a percentage of a
connector count would be inventing connectors.

### Units

| what it is | unit |
|---|---|
| detonating cord, harness wire, bell wire | **metres** |
| surface connectors, downhole detonators, boosters, spacers | **each** |
| explosives | **kilograms** |

Cord and wire are the only things measured by length. A connector has a tube, but you buy
the connector, so it is counted.

### Whole metres, and whole reels

Metres come back rounded to **three decimals at most**. Anything coarser is yours to
choose, using the rounding functions the formula engine already has:

```
fx:floor(cordLength())              whole metres, down
fx:ceil(cordLength())               whole metres, up
fx:roundup(cordLength(), 0)         whole metres, up (same, but takes decimals)
fx:roundup(cordLength() / 5, 0) * 5     whole 5 m REELS
```

**Cord is bought on a reel** — you cannot order 43.2 m — so the last line is the one most
plans want. Change the `5` to whatever your reel length is. Kirra deliberately does not
round to reels for you, because reel length varies by supplier and by product.

**Trunk runs are measured with their closing leg.** A cord loop summed as drawn segments is
short by exactly the leg that makes it a loop.

**A hole that taps a trunk adds no surface cord.** That lead is a *downline* — a different
product family, measured by the depth of its hole, not by the distance out to the trunk.

**Metres are raw geometry.** Tube is bought on a reel and is rounded up to a whole one in
practice; add your own allowance with `"+10%"` or `"+10d"`.

**A product Kirra cannot identify still appears**, under `Unassigned` — an absent line would
read as "not used", which is a different and worse claim than "used, product not recorded".
Set the product on the run in Trunk Properties to clear it.

**Tie-in / harness sheets:**

```
fx:"Path " & harnessLabel(1) & ": " & harnessCount(1) & " dets"
fx:harnessSequence(1, 1)      first hole on path A
fx:harnessPathCount()         how many paths
```

`harnessCount` counts **detonators**, not holes — two primers per hole across ten
connections is twenty.

---

## 7. Graphics

Merge the region first, then put ONE token in the top-left cell:

```
fx:mapView            plan view (raster)
fx:mapView(v, 8pt)    vector plan view, 8pt labels — crisp, scalable, far smaller PDF
fx:legend(vor.pfd.fx, h)
fx:northArrow    fx:scale    fx:scaleBar    fx:scaleText    fx:logo    fx:qrcode
fx:holeSection("Pattern_01", "H001")
fx:sectionView("Pattern_01", "H001", "H010")
```

The font size argument is optional — `fx:mapView(v)` is valid.

**The vector map view draws your KAD drawing the way the screen does.** A polygon you
filled prints filled, in its own colour and opacity. A label prints in its own font, at
its own size — including a **world-sized** label, whose height is set in metres and so
grows and shrinks with the plot scale instead of staying a fixed size on the page. Only
the fonts your drawing actually uses are embedded, so the PDF stays small.

Two things to know when a filled polygon and a label overlap:

- Fill is drawn beneath the polygon's own outline, so the outline always stays crisp.
- Between separate entities, **elevation decides what covers what** — the higher one
  paints on top, exactly as it does on screen. If a filled badge is hiding its own
  number, raise the number's elevation above the badge. Entities at the same elevation
  keep the order they were drawn in.

---

## 8. When it comes out wrong

| Symptom | Cause | Fix |
|---|---|---|
| Everything hole-derived is **0 or blank** | The print sees no holes | Check the Entity Filter, and that the blast is visible. Kirra warns before printing. |
| `#ERR: …` | Unknown function, or a bare `Math.` call | Use a documented function; check spelling. |
| `ERR` | Divide by zero / non-finite | Guard with `if(countif(...)>0, …, "")`. |
| Cell unexpectedly **blank** | `field[N]` index past the last hole | Intended for `[++]` rows. Wrap in `ignore()` to keep it. |
| Text **cut off** | Content taller/wider than the cell | Taller row, merge wider, or split — §5. |
| Firing times look tiny (0–9 ms) | Reading `holeTime` on an electronic blast | Use `fireTime[i]` — §6. |
| Graphic is tiny | Region not merged | Merge the cells — the merged region is the bounding box. |

---

## 9. Reference

**`references/formulas.md`** — in this skill folder — lists **every** variable and function
with an example. **Read it before writing any formula.** It is generated from Kirra itself,
so it always matches the version that produced it. The same list is in the app under
**Print ▸ Formulas**.

**`Kirra-DesignPRINTReferenceTemplate.xlsx`**, shipped alongside this skill, is a working
multi-sheet template — summary, plan views, hole sections, load sheet. Copy sheets from it
rather than starting blank.

### Never invent a name

If a variable or function is not in the generated reference, **it does not exist**. Do not
guess a plausible-looking one — it evaluates to `#ERR` or silently produces nothing. If the
data the user wants isn't listed, say so plainly rather than inventing a field.
