# Kirra Print Template — Formula Reference

Generated from Kirra 1.1.20.238.
Every formula cell starts with `fx:`. A cell without that prefix is printed as-is.

Join text with `&` — e.g. `fx:"Total: " & round(sum(holeLength[i]),1) & " m"`.
Bare `Math.` calls are NOT available; use the maths functions below.

## Scalar Variables

Use on their own — one value for the whole print.

| Name | Description | Example |
|---|---|---|
| `blastName` | User-entered blast name | `"Shot 42"` |
| `designer` | User-entered designer name | `"J. Smith"` |
| `date` | Current date | `"6/03/2026"` |
| `time` | Current time | `"14:30:00"` |
| `datetime` | Current date and time | `"6/03/2026, 14:30:00"` |
| `paperSize` | Paper size | `"A3"` |
| `orientation` | Page orientation | `"landscape"` |
| `printScale` | Calculated print scale | `500` |
| `holeCount` | Total visible holes | `142` |
| `drillMetres` | Total drill metres | `1927.3` |
| `totalMass` | Total explosive mass (kg) | `4250.0` |
| `totalVolume` | Total volume (m3) | `12500.0` |
| `powderFactor` | Overall powder factor (kg/m3) | `0.34` |
| `entityCount` | Number of entities | `2` |
| `entityNames` | Comma-separated entity names | `"Pattern_01, Pattern_02"` |
| `entityName` | First entity name | `"Pattern_01"` |

## Iterated Fields

Use `[i]` inside an aggregation, e.g. `sum(holeLength[i])`. Use `[N]`, `[++]` or `[+>]` to place one hole per cell or row.

| Name | Description | Example |
|---|---|---|
| `holeLength[i]` | Hole length (m) | `sum(holeLength[i])` |
| `holeDiameter[i]` | Hole diameter (mm) | `avg(holeDiameter[i])` |
| `holeAngle[i]` | Hole angle from vertical (deg) | `avg(holeAngle[i])` |
| `holeBearing[i]` | Hole bearing (deg) | `avg(holeBearing[i])` |
| `benchHeight[i]` | Bench height (m) | `avg(benchHeight[i])` |
| `burden[i]` | Burden (m) | `avg(burden[i])` |
| `spacing[i]` | Spacing (m) | `avg(spacing[i])` |
| `holeType[i]` | Hole type | `countif(holeType[i], "Production")` |
| `entityName[i]` | Entity name per hole | `uniqueList(entityName[i])` |
| `measuredMass[i]` | Measured mass (kg) | `sum(measuredMass[i])` |
| `measuredLength[i]` | Measured length (m) | `avg(measuredLength[i])` |
| `holeID[i]` | Hole ID | `count(holeID[i])` |
| `startX[i]` | Collar X (easting) | `min(startX[i])` |
| `startY[i]` | Collar Y (northing) | `max(startY[i])` |
| `startZ[i]` | Collar Z (elevation) | `avg(startZ[i])` |
| `endX[i]` | Toe X (easting) | `endX[1]` |
| `endY[i]` | Toe Y (northing) | `endY[1]` |
| `endZ[i]` | Toe Z (elevation) | `endZ[1]` |
| `gradeX[i]` | Grade X (easting) | `gradeX[1]` |
| `gradeY[i]` | Grade Y (northing) | `gradeY[1]` |
| `gradeZ[i]` | Grade Z (elevation) | `gradeZ[1]` |
| `subdrillAmount[i]` | Subdrill amount (m) | `avg(subdrillAmount[i])` |
| `firstChargeTop[i]` | Collar to first charge top — geometric uncharged zone (m) | `avg(firstChargeTop[i])` |
| `stemLength[i]` | Stemming length — sum of Stemming/StemGel/DrillCuttings decks (m) | `avg(stemLength[i])` |
| `chargeLength[i]` | Total charge column length (m) | `avg(chargeLength[i])` |
| `totalMass[i]` | Charging total mass per hole | `sum(totalMass[i])` |
| `powderFactor[i]` | Powder factor per hole, using the blast's selected volume method (Assign Volume — area basis + effective bench); falls back to mass/(burden×spacing×benchHeight) kg/m³ | `round(avg(powderFactor[i]),2)` |
| `deckCount[i]` | Deck count per hole | `avg(deckCount[i])` |
| `airLength[i]` | Air deck length per hole (m) | `sum(airLength[i])` |
| `inertLength[i]` | Total inert deck length per hole — all non-explosive decks (m) | `sum(inertLength[i])` |
| `waterLength[i]` | Water deck length per hole (m) | `sum(waterLength[i])` |
| `spacerCount[i]` | Count of spacer decks per hole | `sum(spacerCount[i])` |
| `measuredComment[i]` | Measured comment | `measuredComment[1]` |
| `fireTime[i]` | When the hole FIRES (ms). Use this for firing windows — on an electronic blast it is the detonator time, not the surface tie | `max(fireTime[i])` |
| `holeTime[i]` | Surface TIE delay (ms) — the connector between holes, NOT the firing time. Use fireTime[i] for firing times | `max(holeTime[i])` |
| `timingDelay[i]` | Surface tie delay (ms) — same as holeTime[i] | `avg(timingDelay[i])` |

## Indexed Access

How to place a specific hole, or one hole per row/cell.

| Name | Description | Example |
|---|---|---|
| `field[N]` | Access Nth visible hole (1-based). Works with Excel refs: ="fx:holeID["&$A1&"]" | `fx:holeLength[3]` |
| `field[++]` | Auto-increment per row (hole 1, 2, 3...). Blank beyond hole count | `fx:holeID[++]` |
| `field[--]` | Auto-decrement per row (last hole first, counting down) | `fx:holeID[--]` |
| `field[+>]` | Grid-increment per cell (L-to-R, top-to-bottom). Auto-paginates | `fx:holeID[+>]` |

## Directives

Change what the sheet sees before anything else is evaluated.

| Name | Description | Example |
|---|---|---|
| `filter(condition)` | Pre-filter holes for [++]/[+>]. Supports >, <, >=, <=, ==, != with && and \|\| | `fx:filter(holeAngle > 0)` |

## Functions

Aggregation, grouping, maths, text, dates and conditionals.

| Name | Description | Example |
|---|---|---|
| `sum(field[i])` | Sum of field across visible holes | `sum(holeLength[i])` |
| `count(field[i])` | Count of non-null values | `count(holeID[i])` |
| `avg(field[i])` | Average | `avg(holeDiameter[i])` |
| `min(field[i])` | Minimum | `min(startZ[i])` |
| `max(field[i])` | Maximum | `max(startZ[i])` |
| `median(field[i])` | Median | `median(holeLength[i])` |
| `stdev(field[i])` | Standard deviation | `stdev(holeLength[i])` |
| `countif(field[i], val)` | Count where field equals val | `countif(holeType[i], "Production")` |
| `sumif(sumF[i], condF[i], val)` | Sum where condition field equals val | `sumif(holeLength[i], holeType[i], "Production")` |
| `join(field[i], sep)` | Join values as string | `join(holeID[i], ", ")` |
| `uniqueList(field[i], sep)` | Join unique values | `uniqueList(entityName[i])` |
| `round(value, n)` | Round to n decimals (neg n = tens/hundreds) | `round(1927.35, 1) = 1927.4` |
| `roundup(value, n)` | Round up (ceiling) | `roundup(1927.31, 1) = 1927.4` |
| `rounddown(value, n)` | Round down (floor) | `rounddown(1927.39, 1) = 1927.3` |
| `ceil(value)` | Ceiling (round up to integer) | `ceil(12.1) = 13` |
| `floor(value)` | Floor (round down to integer) | `floor(12.9) = 12` |
| `abs(value)` | Absolute value | `abs(-5) = 5` |
| `sqrt(value)` | Square root | `sqrt(9) = 3` |
| `pow(base, exp)` | Power | `pow(2, 3) = 8` |
| `pi()` | Pi constant | `pi() = 3.14159...` |
| `today()` | Today's date | `"6/03/2026"` |
| `today(offset)` | Today +/- days | `today(-1) = yesterday` |
| `now()` | Current date and time | `"6/03/2026, 14:30:00"` |
| `dateformat(fmt)` | Formatted date (YYYY,MM,DD,hh,mm,ss) | `dateformat("DD/MM/YYYY")` |
| `upper(text)` | Uppercase | `upper("hello") = "HELLO"` |
| `lower(text)` | Lowercase | `lower("HELLO") = "hello"` |
| `trim(text)` | Trim whitespace | `trim(entityName)` |
| `left(text, n)` | Left N characters | `left("Hello", 3) = "Hel"` |
| `right(text, n)` | Right N characters | `right("Hello", 3) = "llo"` |
| `len(text)` | String length | `len("Hello") = 5` |
| `text(value, fmt)` | Format number | `text(3.14, "0.0") = "3.1"` |
| `fixed(value, n)` | Fixed decimals | `fixed(3.14, 1) = "3.1"` |
| `if(cond, true, false)` | Conditional | `if(holeCount > 100, "Large", "Small")` |
| `sortCount(field[i], sep, limit)` | Count per unique value, sorted by count desc | `sortCount(holeType[i], ", ")` |
| `groupCount(field[i], sep, order)` | Group and count (order: desc/asc/alpha) | `groupCount(holeType[i], "\n", "desc")` |
| `groupSum(sumF[i], grpF[i], sep)` | Sum grouped by another field | `groupSum(holeLength[i], entityName[i], "\n")` |
| `groupAvg(valF[i], grpF[i], sep)` | Average grouped by another field | `groupAvg(holeDiameter[i], holeType[i], "\n")` |
| `groupMin(valF[i], grpF[i], sep)` | Min grouped by another field | `groupMin(holeLength[i], holeType[i], "\n")` |
| `groupMax(valF[i], grpF[i], sep)` | Max grouped by another field | `groupMax(startZ[i], holeType[i], "\n")` |
| `groupTable(grpF[i], fmt, sep)` | Multi-field per-group format. Tokens: {key} {count} {sum:f} {avg:f} {min:f} {max:f} {median:f} | `groupTable(holeType[i], "{key}: {count} holes, dia={avg:holeDiameter}mm", "\n")` |
| `connectorList(sep)` | List connector delays with counts | `connectorList(", ")` |
| `connectorCount(delay)` | Count connectors (optional: specific delay) | `connectorCount(25)` |
| `harnessPathCount()` | Number of harness paths in the blast | `harnessPathCount() = 3` |
| `harnessLabel(path)` | Path assignment label, 1-based (1=A, 26=Z, 27=AA) | `harnessLabel(1) = "A"` |
| `harnessCount(path)` | Number of DETONATORS on the path (not holes) | `harnessCount(1) = 20` |
| `harnessHoleCount(path)` | Number of holes on the path | `harnessHoleCount(1) = 10` |
| `harnessSequence(path, pos)` | holeID at position pos along the path, in run order from its anchor | `harnessSequence(1, 1) = "A1"` |
| `productList(sep)` | List products with total mass | `productList(", ")` |
| `productMass(name)` | Total mass of a specific product | `productMass("ANFO Heavy")` |
| `productCount(name)` | Count holes using product (or unique product count) | `productCount()` |

## Operators

| Name | Description | Example |
|---|---|---|
| `&` | String concatenation | `"Total: " & sum(holeLength[i]) & "m"` |

## Render Tokens (Graphics)

These draw pictures, not text. Merge the cells first — the merged region is the bounding box.

| Name | Description | Example |
|---|---|---|
| `legend(code, orient)` | Legend — uses same codes as mapView. orient: h=horizontal, v=vertical | `legend(vor.pfd.fx, h)` |
| `northArrow` | North arrow graphic | `northArrow` |
| `scale` | Scale bar + text (combined) | `scale` |
| `scaleBar` | Scale bar graphic only | `scaleBar` |
| `scaleText` | Scale text only (1:XXXX) | `scaleText` |
| `logo` | User logo image | `logo` |
| `qrcode` | QR code graphic | `qrcode` |
| `mapView` | Map view — default raster | `mapView` |
| `mapView(r)` | Raster map view (holes + surfaces + images) | `mapView(r)` |
| `mapView(r, dpi)` | Raster with custom DPI (default 200) | `mapView(r, 300)` |
| `mapView(v)` | Vector map view (holes + connectors, crisp lines) | `mapView(v)` |
| `mapView(v, pt)` | Vector with label font size in points | `mapView(v, 8pt)` |
| `connectorCount` | Connector count table (render) | `connectorCount` |
| `holeSection(entity, holeID)` | Single hole charging section view | `holeSection("Pattern_01", "H001")` |
| `sectionView(entity, holeID1, holeID2)` | Multi-hole bench cross-section between two holes | `sectionView("Pattern_01", "H001", "H010")` |
